package com.gl.balancebracket.main;

import com.gl.balancebracket.service.BalancingBrackets;

public class Driver {
	
	public static void main(String[] args) {
		
		BalancingBrackets bb = new BalancingBrackets();
		
		String bracketExpression = "([[{}]])";
				
				boolean result;
				
				result = bb.checkingBracketsBalanced(bracketExpression);
				
				if(result) {
					System.out.println("The entered String has Balanced Brackets");
				}
				else {
					System.out.println("The entered String is not balanced brackets");
				}
		
	}

}
